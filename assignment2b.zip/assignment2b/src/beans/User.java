package beans;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

@ManagedBean
@ViewScoped
public class User {
	// New variables
	private String firstName;
	private String lastName;
	
	// This is a default constructor that sets the first/last name
	// to Alexander Carrillo.
	public User() {
		firstName="Alexander";
		lastName="Carrillo";
	}

	// These are getters and setters for FirstName and LastName.
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}	
}

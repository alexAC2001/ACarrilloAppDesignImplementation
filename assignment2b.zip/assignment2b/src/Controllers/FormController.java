package Controllers;

// These must be imported so @ManagedBean and @ViewScoped can be used.
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import beans.User;

@ManagedBean
@ViewScoped
// This class will have methods to have actions
// when the user clicks on the page.
public class FormController {

	// The method is used to control what happens when the 
	// user clicks the Submit button.
	public String onSubmit() {
		// This gets the id number/value of this application.
		FacesContext context = FacesContext.getCurrentInstance();
		// This get the user object
		User user = context.getApplication().evaluateExpressionGet(context, "#{user}", User.class);
		
		// These print in the console showing the submit button works.
		System.out.println("You clicked the submit button!");
		System.out.println("The first name is " + user.getFirstName());
		System.out.println("The last name is " + user.getLastName());
		
		// The object, user, is placed in a POST request.
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("user", user);
		
		// This line will display the Response.xhtml page.
		return "Response.xhtml";		
	}
	
	public String onFlash()
	{
		// This gets the id number/value of this application.
		FacesContext context = FacesContext.getCurrentInstance();
		// This get the user object
		User user = context.getApplication().evaluateExpressionGet(context, "#{user}", User.class);
		
		System.out.println("You clicked the flash button!");
		
		// The object, user, is placed in a POST request.
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("user", user);
		
		return "Response2.xhtml";//?faces-redirect=true";		
	}
	
}

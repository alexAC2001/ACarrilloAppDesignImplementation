package assignment2;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class HandleForumInput
 */
@WebServlet("/HandleForumInput")
public class HandleForumInput extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HandleForumInput() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    
    // This doGet method() is what allows the application to have the user
    // input messages and have a response.
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// firstName and lastName are references to the request for firstname and lastname.
		String firstName = request.getParameter("firstname");
		String lastName = request.getParameter("lastname");
		
		// The firstname and lastname are the parameters and firstName and lastName are the values for them.
		request.setAttribute("firstname", firstName);
		request.setAttribute("lastname", lastName);
		
		// The following if statements state that if the first/last names are blank,
		// then request the TestError.jsp file.
		if(firstName.equals("")) 
		{
			request.getRequestDispatcher("TestError.jsp").forward(request, response);
		}
		if(lastName.equals("")) 
		{
			request.getRequestDispatcher("TestError.jsp").forward(request, response);
		}
		if(firstName.equals("") && lastName.equals(""))
		{
			request.getRequestDispatcher("TestError.jsp").forward(request, response);
		}
		
		// This line requests the ResponsePage so the application displays the user's
		// first and last names to them.
		request.getRequestDispatcher("ResponsePage.jsp").forward(request, response);
		
	    //response.getWriter().append("Served at: ").append(request.getContextPath());	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
